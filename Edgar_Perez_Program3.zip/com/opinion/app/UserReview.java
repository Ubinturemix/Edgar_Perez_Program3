/*
Author: Edgar Perez
Assignment: Program 2
Class: CSC 2040
 */

package com.opinion.app;

import com.opinion.Review;
import java.io.Serializable;
import java.util.*;

public class UserReview implements Serializable {
    private static final long serialVersionUID = 1L;

    private final Review review;          // com.opinion.Review (name/rating/comment)
    private final Reviewer reviewer;      // com.opinion.app.Reviewer
    private final List<ReviewApproval> approvals = new ArrayList<>();

    //ctor (Review, Reviewer)
    public UserReview(final Review review, final Reviewer reviewer) {
        if (review == null || reviewer == null)
            throw new IllegalArgumentException("Review and Reviewer can't be null");
        this.review = review;
        this.reviewer = reviewer;
    }

    //overload (Reviewer, Review)
    public UserReview(final Reviewer reviewer, final Review review) {
        this(review, reviewer);
    }

    public Review getReview() {
        return review;
    }


    public Reviewer getReviewer() {
        return reviewer;
    }


    public List<ReviewApproval> getApprovals() {
        return Collections.unmodifiableList(approvals);

    }

    void addApproval(final ReviewApproval a) {
        approvals.add(Objects.requireNonNull(a, "approval"));
    }

    @Override public String toString() {
        return "UserReview{" + reviewer.getEmail() + " -> " + review.name() + "}";
    }
}
