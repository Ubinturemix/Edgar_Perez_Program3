package com.opinion.test;

import com.opinion.Review;
import com.opinion.Rating;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

/*
 Author:     Edgar Perez
 Assignment: Program 3
 CSC 2040 Software Engineering
 */

//JUnit 5 tests for Review (valid/invalid creation, formatting).
public class ReviewTest {


    // Helper for asserting IllegalArgumentException.
    private static IllegalArgumentException iae(Executable e) {
        return assertThrows(IllegalArgumentException.class, e);
    }

    //Helper for checking that an exception message contains a substring (case-insensitive).
    private static void assertMsgHas(IllegalArgumentException ex, String needleLower) {
        assertNotNull(ex.getMessage());
        assertTrue(ex.getMessage().toLowerCase().contains(needleLower));
    }

    @Test
    void createValidReviewBuildsObjectAndFormatsToString() {
        Review r = Review.create("Widget", "TWO", "Nice item");
        assertAll(
                () -> assertEquals("Widget", r.name()),
                () -> assertEquals(Rating.TWO, r.rating()),
                () -> assertEquals("Nice item", r.comment()),
                () -> assertEquals("Widget with rating of TWO star(s): Nice item", r.toString())
        );
    }

    @Test
    void directConstructorIsValidatedAndFormats() {
        Review r = new Review("Gadget", Rating.ONE, "ok");
        assertEquals("Gadget with rating of ONE star(s): ok", r.toString());
    }

    @Test
    void createEnforcesNameLengthBounds() {
        assertMsgHas(iae(() -> Review.create("", "ONE", "ok")), "name");
        assertMsgHas(iae(() -> Review.create("X".repeat(65), "ONE", "ok")), "name");
    }

    @Test
    void createEnforcesCommentLengthBounds() {
        assertMsgHas(iae(() -> Review.create("A", "ONE", "")), "comment");
        String longComment = "Y".repeat(255);
        assertMsgHas(iae(() -> Review.create("A", "ONE", longComment)), "comment");
    }

    @Test
    void createRejectsIllegalCharacters() {
        assertMsgHas(iae(() -> Review.create("Wi#dget", "ONE", "ok")), "#");
        assertMsgHas(iae(() -> Review.create("Widget", "ONE", "bad#comment")), "#");
        assertMsgHas(iae(() -> Review.create("Widget\n", "ONE", "ok")), "printable");
    }
}
